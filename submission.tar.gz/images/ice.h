/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=30x30 ice ice.jpg 
 * Time-stamp: Thursday 11/15/2018, 15:45:18
 * 
 * Image Information
 * -----------------
 * ice.jpg 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ICE_H
#define ICE_H

extern const unsigned short ice[900];
#define ICE_SIZE 1800
#define ICE_LENGTH 900
#define ICE_WIDTH 30
#define ICE_HEIGHT 30

#endif

