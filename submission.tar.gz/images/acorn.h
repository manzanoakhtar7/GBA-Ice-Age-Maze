/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=30x30 acorn acorn.jpg 
 * Time-stamp: Thursday 11/15/2018, 15:44:09
 * 
 * Image Information
 * -----------------
 * acorn.jpg 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ACORN_H
#define ACORN_H

extern const unsigned short acorn[900];
#define ACORN_SIZE 1800
#define ACORN_LENGTH 900
#define ACORN_WIDTH 30
#define ACORN_HEIGHT 30

#endif

