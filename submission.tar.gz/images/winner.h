/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 winner winner.jpg 
 * Time-stamp: Friday 11/16/2018, 22:02:42
 * 
 * Image Information
 * -----------------
 * winner.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINNER_H
#define WINNER_H

extern const unsigned short winner[38400];
#define WINNER_SIZE 76800
#define WINNER_LENGTH 38400
#define WINNER_WIDTH 240
#define WINNER_HEIGHT 160

#endif

