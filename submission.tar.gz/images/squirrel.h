/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=30x30 squirrel squirrel.jpg 
 * Time-stamp: Thursday 11/15/2018, 15:33:43
 * 
 * Image Information
 * -----------------
 * squirrel.jpg 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SQUIRREL_H
#define SQUIRREL_H

extern const unsigned short squirrel[900];
#define SQUIRREL_SIZE 1800
#define SQUIRREL_LENGTH 900
#define SQUIRREL_WIDTH 30
#define SQUIRREL_HEIGHT 30

#endif

