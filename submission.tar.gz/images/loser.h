/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 loser loser.jpg 
 * Time-stamp: Friday 11/16/2018, 22:02:29
 * 
 * Image Information
 * -----------------
 * loser.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSER_H
#define LOSER_H

extern const unsigned short loser[38400];
#define LOSER_SIZE 76800
#define LOSER_LENGTH 38400
#define LOSER_WIDTH 240
#define LOSER_HEIGHT 160

#endif

