Scrat, on his enless quest for acorns, has been caught in an ice maze!
He only has 20 seconds to escape, but collecting acorns from the corners of the maze will give him 5 extra seconds.
Only objects in Scrat's immediate vicinity will be visible.
Use the arrow keys to navigate the maze. Each button press will move Scrat 1 block.